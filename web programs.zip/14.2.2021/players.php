<!DOCTYPE html>

<head>
	<title>Indian Cricket</title>

</head
<body>

	<div id="page-wrap">
		<h1>Indian cricket Players</h1>

		<form action="name.php" method="post">
            	<input type="text" name="pname1"  id="pname1" placeholder="Enter name of a player" /><br>
                <input type="text" name="pname2" id="pname2" placeholder="Enter name of a player" /><br>
                <input type="text"  name="pname3"id="pname3" placeholder="Enter name of a player" /><br>
                <input type="text"  name="pname4"id="pname4" placeholder="Enter name of a player" /><br>
                <input type="text"  name="pname5" id="pname5" placeholder="Enter name of a player" /><br>
                <input type="submit" name="submit" value="Submit">
		</form>
	</div>
</body>
</html>