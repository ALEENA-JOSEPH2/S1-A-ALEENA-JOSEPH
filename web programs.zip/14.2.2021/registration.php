<!DOCTYPE html>
<html>
<body>
<form action="signup.php" method="POST">
  User_name: <input type="text" name="username" /><br />
  Email: <input type="text" name="email" /><br />
  Password: <input type="text" name="password" /><br />
  Confirm_password: <input type="text" name="password_confirm" /><br />
  <input type="submit" value="Register" />
</form>


</body>
</html>
