print("FINDING LARGEST NUMBER")
print("***********************")
number1 = input('Enter  The 1st number: ')
number2 = input('Enter The 2nd Number: ')
number3 =  input('Enter The 3rd Number: ')
if(number1 >= number2) and (number1 >= number3):
    lnumber = number1
elif(number2 >= number1) and (number2 >= number3):
    lnumber = number2
else:
    lnumber = number3
print(f"The Largest Number Is: {lnumber}")