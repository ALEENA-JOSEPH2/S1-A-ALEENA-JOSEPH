
print("SQUARE OF NUMBER")
print("---------------------")
number = input('Enter a number: ')
square = int(number) * int(number)
print("square is:")
print(square)